<?php declare(strict_types=1);

namespace Colo\AfterPay\Resources\snippet\de_DE;

use Shopware\Core\System\Snippet\Files\SnippetFileInterface;

class SnippetFile_de_DE implements SnippetFileInterface
{
    public function getName(): string
    {
        return 'snippets.de-DE';
    }

    public function getPath(): string
    {
        return __DIR__ . '/snippets.de-DE.json';
    }

    public function getIso(): string
    {
        return 'de-DE';
    }

    public function getAuthor(): string
    {
        return 'Arvato AfterPay';
    }

    public function isBase(): bool
    {
        return false;
    }
}
