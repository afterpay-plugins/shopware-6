<?php

return [
    'urls' => [
        'prod' => 'https://api.afterpay.io/api/v3/',
        'public_sandbox' => 'https://sandbox.afterpay.io/api/v3/',
        'partner_test' => 'https://api-pt.afterpay.io/api/v3/',
    ],
];