<?php declare(strict_types=1);

namespace Colo\AfterPay\Subscribers;

use Colo\AfterPay\Service\Payments\InstallmentPayment;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Storefront\Framework\Routing\Router;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpKernel\Event\ControllerArgumentsEvent;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class KernelSubscriber implements EventSubscriberInterface
{

    /**
     * @var ContainerInterface
     */
    private $container;

    /**
     * KernelSubscriber constructor.
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    /**
     * @return array
     */
    public static function getSubscribedEvents(): array
    {
        return [
            KernelEvents::CONTROLLER_ARGUMENTS => ['onKernelEventsControllerArguments', 1],
            KernelEvents::RESPONSE => ['onKernelEventsResponse', 1],
        ];
    }

    /**
     * @param ResponseEvent $event
     */
    public function onKernelEventsResponse(ResponseEvent $event)
    {
        $request = $event->getRequest();
        $attributes = $request->attributes;
        $route = $attributes->get('_route');
        if ($route == 'frontend.checkout.confirm.page') {
            /** @var Session $session */
            $session = $this->container->get('session');
            if ($session->has('ColoAfterpayInstallmentInvalid') && $session->get('ColoAfterpayInstallmentInvalid')) {
                $session->remove('ColoAfterpayInstallmentInvalid');

                /** @var Router $router */
                $router = $this->container->get('router');
                $event->setResponse(new RedirectResponse($router->generate('frontend.account.payment.page', [], Router::ABSOLUTE_URL), 302));
            }
        }
    }

    /**
     * @param ControllerArgumentsEvent $event
     */
    public function onKernelEventsControllerArguments(ControllerArgumentsEvent $event)
    {
        $request = $event->getRequest();
        $attributes = $request->attributes;
        $route = $attributes->get('_route');
        if ($route == 'frontend.checkout.confirm.page') {
            /** @var Session $session */
            $session = $this->container->get('session');

            $arguments = $event->getArguments();
            /** @var SalesChannelContext $salesChannelContext */
            $salesChannelContext = $arguments[1];
            $customer = $salesChannelContext->getCustomer();
            if (empty($customer)) {
                if ($session->has('ColoAfterpayInstallmentInvalid')) {
                    $session->remove('ColoAfterpayInstallmentInvalid');
                }
                return;
            }
            $handlerIdentifier = $salesChannelContext->getPaymentMethod()->getHandlerIdentifier();
            if ($handlerIdentifier === InstallmentPayment::class) {
                if (empty($session->get('ColoAfterpayInstallmentPlan'))) {
                    $session->set('ColoAfterpayInstallmentInvalid', true);
                }
            } else if ($session->has('ColoAfterpayInstallmentInvalid')) {
                $session->remove('ColoAfterpayInstallmentInvalid');
            }
        }
    }
}
