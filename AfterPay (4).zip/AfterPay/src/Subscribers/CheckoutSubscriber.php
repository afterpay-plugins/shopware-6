<?php declare(strict_types=1);

namespace Colo\AfterPay\Subscribers;

use Colo\AfterPay\Checkout\AfterPayData;
use Colo\AfterPay\Service\AfterpayService;
use Colo\AfterPay\Service\Payments\DirectDebitPayment;
use Colo\AfterPay\Service\Payments\InstallmentPayment;
use Colo\AfterPay\Service\Payments\InvoicePayment;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Shopware\Storefront\Page\Checkout\Confirm\CheckoutConfirmPageLoadedEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Colo\AfterPay\Traits\HelperTrait;

class CheckoutSubscriber implements EventSubscriberInterface
{
    use HelperTrait;

    public const AFTERPAY_DATA_EXTENSION_ID = 'afterPayData';

    /**
     * @var ContainerInterface
     */
    private $container;

    /**
     * @var AfterpayService
     */
    private $afterpayService;

    /**
     * CheckoutSubscriber constructor.
     * @param ContainerInterface $container
     * @param AfterpayService $afterpayService
     * @param SystemConfigService $systemConfigService
     */
    public function __construct(ContainerInterface $container, AfterpayService $afterpayService, SystemConfigService $systemConfigService)
    {
        $this->container = $container;
        $this->afterpayService = $afterpayService;
        $this->systemConfigService = $systemConfigService;
    }

    /**
     * @return array
     */
    public static function getSubscribedEvents(): array
    {
        return [
            CheckoutConfirmPageLoadedEvent::class => ['onConfirmPageLoaded', 1]
        ];
    }

    /**
     * @param CheckoutConfirmPageLoadedEvent $event
     */
    public function onConfirmPageLoaded(CheckoutConfirmPageLoadedEvent $event): void
    {
        $salesChannelContext = $event->getSalesChannelContext();
        $variables = [
            'afterPayActive' => false
        ];
        $handlerIdentifier = $salesChannelContext->getPaymentMethod()->getHandlerIdentifier();
        if ($handlerIdentifier === InvoicePayment::class ||
            $handlerIdentifier === DirectDebitPayment::class ||
            $handlerIdentifier === InstallmentPayment::class) {
            $variables['afterPayActive'] = true;
            $variables['merchantId'] = $this->afterpayService->getMerchantId($salesChannelContext);
            $variables['tosCheckbox'] = $this->getPluginConfig($salesChannelContext->getSalesChannelId(), 'showTosCheckbox');
            $variables['languageCode'] = $this->getLanguageCode($salesChannelContext);
            $variables['merchantPaymentMethod'] = $handlerIdentifier::getName();
            $variables['paymentMethodName'] = $salesChannelContext->getPaymentMethod()->getTranslation('name');
            $variables['paymentMethodId'] = $salesChannelContext->getPaymentMethod()->getId();
        }
        $afterPayData = (new AfterPayData())->assign($variables);
        $event->getPage()->addExtension(
            self::AFTERPAY_DATA_EXTENSION_ID,
            $afterPayData
        );
    }

    /**
     * @param SalesChannelContext $salesChannelContext
     * @return string
     */
    private function getLanguageCode(SalesChannelContext $salesChannelContext)
    {
        return 'de_DE';
    }
}
